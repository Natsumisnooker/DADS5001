# Role Attractiveness — One Pager

## Top 10 Roles (most attractive)
- **Associate Machine Learning Engineer / Data Scientist May 2020 Undergrad | Level: Entry Level | State: NY** — RAI 66.4 | RPP~63136 | Pay~74500 | Neutral: Stay with conditions / negotiate scope; Drivers: strong RPP vs peers, pay ≥ p60 @ level, good rating
- **Associate Data Scientist - Computer Scientist | Level: Entry Level | State: VA** — RAI 65.6 | RPP~79746 | Pay~81500 | Neutral: Stay with conditions / negotiate scope; Drivers: strong RPP vs peers, pay ≥ p60 @ level, rating downside
- **Associate Data Engineer | Level: Entry Level | State: DC** — RAI 64.5 | RPP~48771 | Pay~65500 | Neutral: Stay with conditions / negotiate scope; Drivers: strong RPP vs peers, pay ≥ p60 @ level
- **IT Associate Data Analyst | Level: Entry Level | State: MA** — RAI 63.1 | RPP~39091 | Pay~54000 | Neutral: Stay with conditions / negotiate scope; Drivers: strong RPP vs peers, pay ≥ p60 @ level
- **Customer Data Scientist/Sales Engineer | Level: Mid Level | State: IL** — RAI 62.9 | RPP~148009 | Pay~137500 | Neutral: Stay with conditions / negotiate scope; Drivers: strong RPP vs peers, pay ≥ p60 @ level, compression risk, good rating
- **Machine Learning Engineer | Level: Mid Level | State: CO** — RAI 62.9 | RPP~97195 | Pay~100500 | Neutral: Stay with conditions / negotiate scope; Drivers: strong RPP vs peers, pay ≥ p60 @ level, compression risk, good rating
- **Senior Data Engineer | Level: Senior Level | State: IN** — RAI 62.5 | RPP~128947 | Pay~122500 | Neutral: Stay with conditions / negotiate scope; Drivers: strong RPP vs peers, pay ≥ p60 @ level, compression risk, good rating
- **Senior Data Engineer | Level: Senior Level | State: TX** — RAI 62.1 | RPP~146903 | Pay~138500 | Neutral: Stay with conditions / negotiate scope; Drivers: strong RPP vs peers, pay ≥ p60 @ level, compression risk, good rating
- **Associate Data Analyst - Graduate Development Program | Level: Entry Level | State: OH** — RAI 61.9 | RPP~48158 | Pay~45500 | Neutral: Stay with conditions / negotiate scope; Drivers: strong RPP vs peers, pay ≥ p60 @ level
- **Associate Data Analyst | Level: Entry Level | State: CO** — RAI 61.3 | RPP~28530 | Pay~29500 | Neutral: Stay with conditions / negotiate scope; Drivers: strong RPP vs peers, pay ≥ p60 @ level, rating downside

## Bottom 10 Roles (least attractive)
- **Lead Data Analyst | Level: Mid Level | State: NY** — RAI 6.0 | RPP~39831 | Pay~47000 | Consider Negotiation / Explore Alternatives; Drivers: weak RPP vs peers, pay ≤ p40 @ level, compression risk, good rating
- **Associate Data Science - Internal Audit | Level: Mid Level | State: MA** — RAI 5.3 | RPP~45244 | Pay~62500 | Consider Negotiation / Explore Alternatives; Drivers: weak RPP vs peers, pay ≤ p40 @ level, compression risk, rating downside
- **Clinical Data Analyst | Level: Mid Level | State: VA** — RAI 5.0 | RPP~68982 | Pay~70500 | Consider Negotiation / Explore Alternatives; Drivers: weak RPP vs peers, pay ≤ p40 @ level, compression risk, good rating
- **Senior Engineer, Data Management Engineering | Level: Senior Level | State: CA** — RAI 4.6 | RPP~75294 | Pay~98500 | Consider Negotiation / Explore Alternatives; Drivers: weak RPP vs peers, pay ≤ p40 @ level, compression risk
- **Data Scientist - Research | Level: Mid Level | State: MA** — RAI 3.8 | RPP~40901 | Pay~56500 | Consider Negotiation / Explore Alternatives; Drivers: weak RPP vs peers, pay ≤ p40 @ level, compression risk, rating downside
- **Data Analyst - Chemist Quality System Contractor | Level: Mid Level | State: CA** — RAI 3.5 | RPP~65357 | Pay~85500 | Consider Negotiation / Explore Alternatives; Drivers: weak RPP vs peers, pay ≤ p40 @ level, compression risk, rating downside
- **Digital Marketing & ECommerce Data Analyst | Level: Mid Level | State: CA** — RAI 3.2 | RPP~39367 | Pay~51500 | Consider Negotiation / Explore Alternatives; Drivers: weak RPP vs peers, pay ≤ p40 @ level, compression risk
- **Marketing Data Analyst | Level: Mid Level | State: CA** — RAI 2.4 | RPP~37074 | Pay~48500 | Consider Negotiation / Explore Alternatives; Drivers: weak RPP vs peers, pay ≤ p40 @ level, compression risk
- **R&D Specialist/ Food Scientist | Level: Mid Level | State: IL** — RAI 1.4 | RPP~56512 | Pay~52500 | Consider Negotiation / Explore Alternatives; Drivers: weak RPP vs peers, pay ≤ p40 @ level, compression risk, rating downside
- **Data Analyst | Level: Mid Level | State: MD** — RAI 0.8 | RPP~54741 | Pay~62000 | Consider Negotiation / Explore Alternatives; Drivers: weak RPP vs peers, pay ≤ p40 @ level, compression risk, rating downside